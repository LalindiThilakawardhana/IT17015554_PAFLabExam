$(document).on("click" , "#btnLogin" , function()
{
	var result = isValidFormLogin();
	if (result== "true")
	{  $("#formLogin").submit(); }
	else
		{$ ("#divStsMsLogin").html(result);
		}
});

//----edit---
$(document).on("click", "#btnEdit", function()
{
			$("#hidMode").val("update");
			$("#hid").val($(this).attr("param"));
			$("#textItemName").val($(this).closet("tr").find('td:eq(1)').text());
			$("#textItemDesc").val($(this).closet("tr").find('td:eq(2)').text());
			
});


//-------remove------
$(document).on("click", "#btnRemove", function()
		{
			var result= confirm("Are you sure?");
			$("#hidMode").val("remove");
			$("#hid").val($(this).attr("param"));
			if(result=="true"){
				$("#formItem").submit();
			}
			else{
				$("#formItem").html(result);
			}
		});
		


