package com.register;


	
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

	import com.mysql.jdbc.Statement;

	public class User {
		
		public String login(String userIn, String pwd) {
			Connection con = null;
			Statement st = null;
			ResultSet rs= null;
			
			String userNameDB = "";
			String pwdDB = "";
			
			try {
				con = DBConnection.createConnection();
				st = con.createStatement();
				rs= st.executeQuery("select nameUser, pwd from User");
				
				while(rs.next()) {
					userNameDB =rs.getString("nameUsers");
					pwdDB = rs.getString("password");
				
					if(userN.equals(userNameDB)&& passwd.equals(pwdDB)) {
						return "SUCCESS";
					}
				}
			}
			catch(SQLException e) {
				e.printStackTrace();
			}
			
			return "Invalid user creadentials.....";
			
		}

	}
	
	function isValidFormLogin()
	{
		if($.trim($("#txtUserName").val())=="")
			{
			return "Enter username";
			
			}
		
		if($.trim($("#txtPassword").val())=="")
		{
		return "Enter Enter Password";
		
	}
		return "true";
	}



